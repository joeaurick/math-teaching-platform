'use client'

import {
  useState,
  useTransition,
} from 'react'
import { Send } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { createClient } from '@/lib/supabase/client'

type ChatMessage = {
  id: string
  conversation_id: string
  sender_profile_id: string | null
  sender_student_access_id: string | null
  message: string
  created_at: string
}

type ChatComposerProps = {
  token: string
  studentAccessId: string
  conversationId: string | null
  onMessageSent: (message: ChatMessage) => void
}

export function ChatComposer({
  token,
  studentAccessId,
  conversationId,
  onMessageSent,
}: ChatComposerProps) {
  const [message, setMessage] = useState('')
  const [isPending, startTransition] =
    useTransition()

  function handleSubmit(
    event: React.FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault()

    const trimmedMessage = message.trim()

    if (!trimmedMessage || isPending) {
      return
    }

    if (!conversationId) {
      window.alert(
        'Belum ada percakapan dengan guru.',
      )
      return
    }

    startTransition(async () => {
      const supabase = createClient()

      // --------------------------------------------------------
      // Kirim pesan
      // --------------------------------------------------------

      const { error: sendError } =
        await supabase.rpc(
          'send_student_chat_message',
          {
            access_token: token,
            target_conversation_id:
              conversationId,
            message_text: trimmedMessage,
          },
        )

      if (sendError) {
        window.alert(
          `Gagal mengirim pesan: ${sendError.message}`,
        )
        return
      }

      // --------------------------------------------------------
      // Ambil ulang messages dari database
      //
      // Ini sengaja dilakukan setelah INSERT berhasil.
      // Kita tidak menggunakan hasil return INSERT karena
      // bentuk return RPC dapat berbeda.
      // --------------------------------------------------------

      const {
        data: messageData,
        error: messagesError,
      } = await supabase.rpc(
        'get_student_chat_messages_by_token',
        {
          access_token: token,
          target_conversation_id:
            conversationId,
        },
      )

      if (messagesError) {
        window.alert(
          `Pesan berhasil dikirim, tetapi gagal mengambil pesan terbaru: ${messagesError.message}`,
        )

        setMessage('')
        return
      }

      const messages =
        (messageData ?? []) as ChatMessage[]

      // --------------------------------------------------------
      // Cari pesan yang baru saja dikirim.
      //
      // Karena pesan terbaru adalah pesan terakhir setelah
      // INSERT berhasil, kita ambil item terakhir.
      // --------------------------------------------------------

      const latestMessage =
        messages.length > 0
          ? messages[messages.length - 1]
          : null

      if (latestMessage) {
        onMessageSent(latestMessage)
      }

      setMessage('')
    })
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="flex items-end gap-3"
    >
      <textarea
        value={message}
        onChange={(event) =>
          setMessage(event.target.value)
        }
        placeholder="Ketik pesan kepada guru..."
        rows={2}
        disabled={
          isPending || !conversationId
        }
        className="min-h-[52px] flex-1 resize-none rounded-xl border border-white/[0.10] bg-white/[0.04] px-4 py-3 text-sm text-white outline-none transition-colors placeholder:text-white/25 focus:border-white/[0.20] disabled:cursor-not-allowed disabled:opacity-50"
      />

      <Button
        type="submit"
        size="icon"
        disabled={
          isPending ||
          !conversationId ||
          message.trim().length === 0
        }
        aria-label="Kirim pesan"
      >
        <Send className="h-4 w-4" />
      </Button>
    </form>
  )
}