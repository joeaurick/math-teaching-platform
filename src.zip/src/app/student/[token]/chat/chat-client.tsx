'use client'

import { useCallback, useState } from 'react'

import { ChatComposer } from './chat-composer'

type ChatMessage = {
  id: string
  conversation_id: string
  sender_profile_id: string | null
  sender_student_access_id: string | null
  message: string
  created_at: string
}

type ChatClientProps = {
  token: string
  studentAccessId: string
  conversationId: string | null
  initialMessages: ChatMessage[]
}

export function ChatClient({
  token,
  studentAccessId,
  conversationId,
  initialMessages,
}: ChatClientProps) {
  const [messages, setMessages] =
    useState<ChatMessage[]>(initialMessages)

  const handleMessageSent = useCallback(
    (message: ChatMessage) => {
      setMessages((current) => {
        const exists = current.some(
          (item) => item.id === message.id,
        )

        if (exists) {
          return current
        }

        return [...current, message]
      })
    },
    [],
  )

  return (
    <>
      <div className="min-h-[420px] space-y-4 p-5 sm:p-6">
        {messages.length === 0 ? (
          <div className="flex min-h-[320px] flex-col items-center justify-center text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/[0.04]">
              <div className="text-lg text-white/30">
                💬
              </div>
            </div>

            <p className="mt-4 text-sm font-medium text-white/70">
              Belum ada pesan
            </p>

            <p className="mt-1 max-w-sm text-xs leading-5 text-white/30">
              Kirim pesan kepada guru untuk memulai
              percakapan.
            </p>
          </div>
        ) : (
          messages.map((message, index) => {
            const isStudent =
              message.sender_profile_id === null

            return (
              <div
                key={`${message.id}-${index}`}
                className={`flex ${
                  isStudent
                    ? 'justify-end'
                    : 'justify-start'
                }`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 sm:max-w-[70%] ${
                    isStudent
                      ? 'bg-white text-black'
                      : 'border border-white/[0.08] bg-white/[0.05] text-white'
                  }`}
                >
                  <p className="whitespace-pre-wrap text-sm leading-6">
                    {message.message}
                  </p>

                  <p
                    className={`mt-1.5 text-[11px] ${
                      isStudent
                        ? 'text-black/40'
                        : 'text-white/25'
                    }`}
                  >
                    {new Date(
                      message.created_at,
                    ).toLocaleString('id-ID', {
                      dateStyle: 'short',
                      timeStyle: 'short',
                    })}
                  </p>
                </div>
              </div>
            )
          })
        )}
      </div>

      <div className="border-t border-white/[0.08] p-4 sm:p-5">
        <ChatComposer
          token={token}
          studentAccessId={studentAccessId}
          conversationId={conversationId}
          onMessageSent={handleMessageSent}
        />
      </div>
    </>
  )
}