'use client'

import { useCallback, useState } from 'react'

import { ChatRealtime } from './chat-realtime'

type ChatMessage = {
  id: string
  conversation_id: string
  sender_profile_id: string | null
  sender_student_access_id: string | null
  message: string
  created_at: string
}

type ChatRoomProps = {
  conversationId: string | null
  initialMessages: ChatMessage[]
  currentTeacherProfileId: string
}

export function ChatRoom({
  conversationId,
  initialMessages,
  currentTeacherProfileId,
}: ChatRoomProps) {
  const [messages, setMessages] =
    useState<ChatMessage[]>(initialMessages)

  const handleMessage = useCallback(
    (message: ChatMessage) => {
      setMessages((current) => {
        const exists = current.some(
          (item) => item.id === message.id,
        )

        if (exists) {
          return current
        }

        return [...current, message]
      })
    },
    [],
  )

  return (
    <>
      {conversationId && (
        <ChatRealtime
          conversationId={conversationId}
          onMessage={handleMessage}
        />
      )}

      <div className="space-y-3">
        {messages.length === 0 ? (
          <div className="rounded-lg border border-border p-6 text-center text-sm text-muted-foreground">
            Belum ada pesan.
          </div>
        ) : (
          messages.map((message) => {
            const isTeacher =
              message.sender_profile_id ===
              currentTeacherProfileId

            return (
              <div
                key={message.id}
                className={`flex ${
                  isTeacher
                    ? 'justify-end'
                    : 'justify-start'
                }`}
              >
                <div
                  className={`max-w-[75%] rounded-lg px-4 py-3 ${
                    isTeacher
                      ? 'bg-primary text-primary-foreground'
                      : 'border border-border bg-card'
                  }`}
                >
                  <p className="whitespace-pre-wrap text-sm">
                    {message.message}
                  </p>

                  <p
                    className={`mt-1 text-xs ${
                      isTeacher
                        ? 'text-primary-foreground/70'
                        : 'text-muted-foreground'
                    }`}
                  >
                    {new Date(
                      message.created_at,
                    ).toLocaleTimeString('id-ID', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              </div>
            )
          })
        )}
      </div>
    </>
  )
}